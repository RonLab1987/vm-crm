<?php 
include_once 'pricelist_class.php'; 

$pricelist = new pricelist;
echo $pricelist->pricelistGroupOptionList();
?>

